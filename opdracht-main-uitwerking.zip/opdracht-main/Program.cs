﻿using System;
using System.Collections.Generic;
using System.Linq;

public class HelloWorld
{

    // The solution should be to recursively seperate the array trough the middle until we end up with arrays
    // of size one or run out of budget K. We should track the cost at each seperation and add this to the number
    // of total possible seperations, subtract the cost from budget K.

    //Example Input

    //N: 6
    //K: 4
    //1 2 3 4 5 6

    //Expected Output:

    //2

    static public void Main()
    {
        // Read N
        int N = Convert.ToInt32(Console.ReadLine());

        // Read K
        int K = Convert.ToInt32(Console.ReadLine());

        // Read array
        string[] parts = Console.ReadLine().Split(' ');
        int[] arr = Array.ConvertAll(parts, int.Parse);

        // Call the function
        int result = Max(N, K, arr);
        Console.WriteLine(result);
    }

    // NOT DONE
    static int Max(int N, int K, int[] arr)
    {
        if (N == 0)
            return 0;

        int possibleSeperations = 0;

        // Keep seperating in the middle until K runs out. Skip
        while (K > 0) {
            // Start seperating from the middle out
            int middle = arr.Length / 2;

            // Seperate array
            int[] left = arr.Take(middle).ToArray();
            int[] right = arr.Skip(middle).ToArray();

            // Validate seperation
            if (!HasEqualOddAndEven(left) || !HasEqualOddAndEven(right))
                continue;

            // Calculate cost
            int cost = Math.Abs(arr[middle] - arr[middle + 1]);

            K -= cost;
        }

        return possibleSeperations;
    }

    static bool HasEqualOddAndEven(int[] array)
    {
        // TODO: Implement
        // Check if array has an equal amount of odds and evens
        return false;
    }
}