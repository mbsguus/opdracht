-- QUERY1

-- QUERY2
SELECT *
FROM Employees
(SELECT AVG(SALARY) FROM Employees WHERE HireDate < '01-01-2021');

-- QUERY3
-- Ik lees deze vraagstelling als twee aparte queries:
-- 1: Hoe veel medewerkers per afdeling
-- 2: Hoe veel medewerkers hebben geen manager

-- Query 3.1
SELECT COUNT(EmployeeId) AS EmployeeCount, Department
FROM Employees
GROUP BY Department;

-- Query 3.2
SELECT COUNT(EmployeeId) AS 'Employees without manager'
FROM Employees
WHERE ManagerId IS null;

-- QUERY4
SELECT CONCAT(FirstName, ' ' , LastName) AS 'FullName', Department, HireDate
FROM Employees
WHERE HireDate >
(SELECT DATEADD(year, -3, GETDATE()));

-- QUERY5